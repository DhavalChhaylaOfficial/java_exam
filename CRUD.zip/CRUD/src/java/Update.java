/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class Update extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String id = request.getParameter("id");
        String name = "";
        String age = "";
        Connection con;
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","admin");
            String query = "Select * from Student5 where id=" + id;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            if (rs.next()) {

                name = rs.getString("name");
                age = rs.getString("age");
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        out.println("<html>");
        out.println("<body bgcolor = 'LightSkyBlue'>");
        out.println("<center><h1>Update Student <h1> <Center>");
        out.println("<form action='Edit'>");

        out.println("<table border = '1' align='center' bgcolor='cyan' >");

        out.println("<tr>");
        out.println("<td>Student No:</td>");
        out.println("<td> " + id + "<input type ='hidden' name='id'value ='"+id+"' > </td>");

        out.println("</tr>");

        out.println("<tr>");
        out.println("<td>Student Name:</td>");
        out.println("<td><input type='text' name='name' value='" + name + "'></td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td>Student Age:</td>");
        out.println("<td><input type='text' name='age' value='" + age + "'></td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<th colspan='2'><input type='submit' value='Submit'></th>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }

}
