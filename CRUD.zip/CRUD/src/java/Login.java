/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author megha
 */
public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest requst, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor = 'LightSkyBlue'>");
        out.println("<center>");
        out.println("<h1>Login Page</h1>");
        out.println("<form action='Validate'>");
        out.println("<table border = '1' align='center' bgcolor='yellow' >");
        out.println("<tr><td>UserName : <input type='text'name='username'></td><tr>");
        out.println("<tr><td>Password : <input type='password'name='password'></td></tr>");
        out.println("<tr><th colspan='2'><input type='submit'value='Submit'></th></tr>");
        out.println("</table>");
        out.println("</form>");
        out.println("</center></body></html>");
    }
}
