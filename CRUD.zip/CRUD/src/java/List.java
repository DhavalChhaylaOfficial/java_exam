/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class List extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor= 'cyan'>");
        out.println("<center><h1> CRUD Operation On Student Table<h1></Center>");

        Connection con = null;
        try {
            //Loading driver
            Class.forName("oracle.jdbc.OracleDriver");
            //Building bridge between java & database
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            //Building query
            String query = "Select * from Student5";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            out.println("<table border = '1' align='center'>");
            out.println("<tr>");
            out.println("<th> Student Sno</th>");
            out.println("<th> Student Sname</th>");
            out.println("<th> Student Sage</th>");
            out.println("<th>Update</th>");
            out.println("<th>Delete</th>");
            out.println("</tr>");
            while (rs.next()) {
                String id = rs.getString("id");
                String age = rs.getString("age");
                String name = rs.getString("name");
                out.println("<tr>");
                out.println("<td>" + id + " </td>");
                out.println("<td>" + name + "</td>");
                out.println("<td>" + age + "</td>");
                out.println("<td> <a href = 'Update?id=" + id + "'>Update</a></td>");
                out.println("<td> <a href = 'Delete?id=" + id + "' > Delete </a> </td>");
            }

            out.println("</table>");
            out.println("<br><Center><a href = 'Add'>Add NewStudent</a > </ enter> <br>");
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            out.println(e);
        }
        out.println("</body>");
        out.println("</html>");
    }

}
