/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class Insert extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<center><h1>Insert Student <h1> <Center>");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String password = request.getParameter("password");
        Connection con = null;
        try {
            Class.forName("oracle.jdbc.OracleDriver");

            con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","admin");
            //Building query
            String query = "Insert into Student5 values(" + id + ",'" + name + "'," + age
                    + ",'" + password + "')";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            stmt.close();
            con.close();
        } catch (Exception e) {
            out.println(e);
        }
        response.sendRedirect("List");
        out.println("</body>");
        out.println("</html>");
    }

}
