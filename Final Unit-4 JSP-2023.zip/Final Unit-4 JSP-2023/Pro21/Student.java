/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package KK;
import java.sql.*;
/**
 *
 * @author CHARUSAT
 */
public class Student {
    
    ResultSet getStudList()
    {
     Connection con;

     try
       {
           Class.forName("oracle.jdbc.OracleDriver");
           con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","KK","KK");

           String query="Select * from Student order by Sno";

           Statement stmt=con.createStatement();
           ResultSet rs=stmt.executeQuery(query);
 
           return rs; 
       }
       catch(Exception e) 
       {
         System.out.println(e);
         return null;
       }
   }
 
}
