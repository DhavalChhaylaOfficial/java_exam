package ApplicationAssignment;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class Register extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String rid = request.getParameter("rid");
            String firstName = request.getParameter("firstname");
            String lastName = request.getParameter("lastname");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            Model model = new Model(rid, firstName, lastName, email, password);
            
        
        try {
        Connection con;
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "ADMIN");
            String sql = "INSERT INTO regis VALUES (?,?, ?, ?, ?)";

            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, model.getRid());
            pstmt.setString(2, model.getFirstName());
            pstmt.setString(3, model.getLastName());
            pstmt.setString(4, model.getEmail());
            pstmt.setString(5, model.getPassword());
            int i = pstmt.executeUpdate();
            if (i > 0) {

                String script = "<script>alert('Registration successful!');</script>";
                response.getWriter().write(script);
                response.sendRedirect("Login.jsp");
            } else {
                response.getWriter().write("Registration failed!");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
        
     

    
}