/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ApplicationAssignment;

import jakarta.servlet.http.HttpServlet;

public class HomeController extends HttpServlet {

  

}
