package ApplicationAssignment;


import ApplicationAssignment.Model;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */


public class LoginController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String rid = request.getParameter("rid");
         String firstName = request.getParameter("firstname");
            String lastName = request.getParameter("lastname");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
             Model model = new Model(rid,firstName, lastName, email, password);
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "ADMIN");
          PreparedStatement pstmt1 = con.prepareStatement("SELECT * FROM regis WHERE EMAIL=? AND PASSWORD=?");
            pstmt1.setString(1, model.getEmail());
            pstmt1.setString(2, model.getPassword());

            ResultSet rs = pstmt1.executeQuery();
            if (rs.next()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("email", email);
                 session.setAttribute("password", password);
                response.sendRedirect("Home.jsp");
            }
             } catch (Exception e) {
            e.printStackTrace();
        }
    }

    

}
