/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;


public class Session3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor= 'orange'>");
        HttpSession session=request.getSession();
        String user=(String)session.getAttribute("uid");
        String password=(String)session.getAttribute("pwd");

        out.println("Hello " + user + "<br>");
        out.println("Your password is: " + password + "<br>");

        out.println("<form action='Session4'>");
        out.println("<input type='submit' value='Submit'><br>");
        out.println("</form>");
        
        out.println("</body>");
        out.println("</html>");
        
        
    }

    
}
