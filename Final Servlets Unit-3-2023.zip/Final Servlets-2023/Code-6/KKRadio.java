/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class KKRadio extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("Text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        out.println("<Center>");
        out.println("<body bgcolor='pink'>");
        out.println("<Font size='25' Font color='blue'>");
        int num1= Integer.parseInt(request.getParameter("fno"));
        int num2= Integer.parseInt(request.getParameter("sno"));
        String opr= request.getParameter("oper");
        int res= 0;
        if(opr.equals("sum"))
            res= num1+num2;
        if(opr.equals("sub"))
            res= num1-num2;
        if(opr.equals("mul"))
            res= num1*num2;
        if(opr.equals("div"))
            res= num1/num2;
        
        out.println("<b>Result : " + res);
        
        out.println("</Center>");
        out.println("</body>");
        out.println("</html>");
    }

    
}
