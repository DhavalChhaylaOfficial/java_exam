 <servlet>
        <servlet-name>PKLoginForm</servlet-name>
        <servlet-class>kk.PKLoginForm</servlet-class>
    </servlet>
    <servlet>
        <servlet-name>PKValidate</servlet-name>
        <servlet-class>kk.PKValidate</servlet-class>
    </servlet>
    <servlet>
        <servlet-name>WelcomePage</servlet-name>
        <servlet-class>kk.WelcomePage</servlet-class>
    </servlet>
    
    <servlet-mapping>
        <servlet-name>PKLoginForm</servlet-name>
        <url-pattern>/PKLoginForm</url-pattern>
    </servlet-mapping>
    <servlet-mapping>
        <servlet-name>PKValidate</servlet-name>
        <url-pattern>/PKValidate</url-pattern>
    </servlet-mapping>
    <servlet-mapping>
        <servlet-name>WelcomePage</servlet-name>
        <url-pattern>/WelcomePage</url-pattern>
    </servlet-mapping>

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class PKLoginForm extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor = 'cyan'>");
        out.println("<Center>");
        out.println("<B> Registration Form ");
        out.println("<Form action = 'PKValidate' method = 'Post'><br>");
        out.println("User Name: <Input type = 'text' name = 'uname'><br><br>");
        out.println("Password : <Input type = 'text' name = 'upwd'><br><br>");
        out.println("<Input type = 'Submit' value = 'Login'>");
        out.println("</Center>");
        out.println("</body>");
        out.println("</html>");
    }

   
}
