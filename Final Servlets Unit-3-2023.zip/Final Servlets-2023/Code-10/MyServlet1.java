Web.xml:
<?xml version="1.0" encoding="UTF-8"?>
<web-app version="6.0" xmlns="https://jakarta.ee/xml/ns/jakartaee" 
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd">
<servlet>
        <servlet-name>MyServlet1</servlet-name>
        <servlet-class>kk.MyServlet1</servlet-class>
        <init-param> 
            <param-name> driver</param-name>s
            <param-value>oracle.jdbc.OracleDriver</param-value>
        </init-param>
       
    </servlet>

<servlet-mapping>
        <servlet-name>MyServlet1</servlet-name>
        <url-pattern>/MyServlet1</url-pattern>
    </servlet-mapping>
</web-app>

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MyServlet1 extends HttpServlet {
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor='cyan'>");
        ServletConfig config = getServletConfig();
        String driver = config.getInitParameter("driver");
        out.println("<b>Driver Name from Web.xml Configuration file : " + driver);
        out.println("</body>");
        out.println("</html>");
    }
}