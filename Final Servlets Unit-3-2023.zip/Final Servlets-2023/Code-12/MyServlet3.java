Web.XML

<servlet>
        <servlet-name>MyServlet3</servlet-name>
        <servlet-class>kk.MyServlet3</servlet-class>
    </servlet>
<context-param>
        <param-name>KK </param-name>
        <param-value> Advance Java</param-value>
    </context-param>
<servlet-mapping>
        <servlet-name>MyServlet3</servlet-name>
        <url-pattern>/MyServlet3</url-pattern>
    </servlet-mapping>


package kk;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class MyServlet3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor='cyan'>");
        //Creating ServletContext object
        ServletContext context = getServletContext();
        //Getting the value of the initialization parameter and printing it  
        String str= context.getInitParameter("KK");
        out.println(" The value of Param-Name from Web.xml :" + str);
        out.println("</body>");
        out.println("</html>");
        
    }

    

}
