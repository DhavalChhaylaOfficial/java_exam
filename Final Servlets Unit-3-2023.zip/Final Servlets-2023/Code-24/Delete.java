/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


public class Delete extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");
        String sno=request.getParameter("sno");
        Connection con=null;
        try
        {
             
             //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            //Building bridge between java & database
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "KK", "KK");
            //Building query
            String query="Delete from Student where Sno=" + sno;
            Statement stmt=con.createStatement();
            stmt.executeUpdate(query);
            stmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        response.sendRedirect("List");

        out.println("</body>");
        out.println("</html>");
    }

    
}
