import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class Add extends HttpServlet 
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
         out.println("<body bgcolor='cyan'>");

     Connection con=null;
     int sno=0;

     try
       {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "kk");

         String query="Select max(sno) maxnum from student";

        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery(query);
 
         if(rs.next())
          {
            sno=rs.getInt("maxnum");
          }

        out.println("</table>");

         rs.close();
         stmt.close();
         con.close();
       }
    catch(Exception e) 
       {
         System.out.println(e);
       }

     sno++;

        out.println("<form action='Insert'>");
        out.println("<table align='center' bgcolor='yellow'>");

        out.println("<tr><td>Student No:</td><td>" + sno + "<input type='hidden' name='sno' value='" + sno + "'></td></tr>");
        out.println("<tr><td>Student Name:</td><td> <input type='text' name='sname'></td><tr>");
        out.println("<tr><td>Student Age:</td><td> <input type='text' name='age'></td></tr>");
        out.println("<tr><th colspan='2'><input type='submit' value='Submit'></th></tr>");
        out.println("</table>");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }
}
