import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class Update extends HttpServlet 
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

     String sno=request.getParameter("sno"); 

     Connection con=null;
      String sname="";          
      String age="";          
      

     try
       {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "kk");

         String query="Select * from student where sno=" + sno;

         Statement stmt=con.createStatement();
         ResultSet rs=stmt.executeQuery(query);

         if(rs.next())         
          {
            sname=rs.getString("sname");   
            age=rs.getString("age");   
          }          

        rs.close();
        stmt.close();
        con.close();
       }
     catch(Exception e)
       {
         System.out.println(e);
       }


        out.println("<html>");
        out.println("<body>");

        out.println("<form action='Edit'>");

        out.println("<table bgcolor='cyan' align='center'>");

        out.println("<tr>");
        out.println("<td>Student No:</td>");
        out.println("<td>" + sno + "<input type='hidden' name='sno' value='" +sno + "'></td>");
        out.println("</tr>");

        out.println("<tr>");
        out.println("<td>Student Name:</td>");
        out.println("<td><input type='text' name='sname' value='" + sname + "'></td>");
        out.println("</tr>");

        out.println("<tr>");
        out.println("<td>Student Age:</td>");
        out.println("<td><input type='text' name='age' value=" + age + "></td>");
        out.println("</tr>");

        out.println("<tr>");
        out.println("<th colspan='2'><input type='submit' value='Submit'></th>");
        out.println("</tr>");

        out.println("</table>");

        out.println("</form>");


        out.println("</body>");
        out.println("</html>");
    }
}
