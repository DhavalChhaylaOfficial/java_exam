import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class Insert extends HttpServlet 
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
         out.println("<body bgcolor='cyan'>");

      String sno=request.getParameter("sno");
      String sname=request.getParameter("sname");
      String age=request.getParameter("age");

     Connection con=null;

     try
       {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "kk");

         String query="Insert into student values(" + sno + ",'" + sname + "'," + age + ")";

         Statement stmt=con.createStatement();
         stmt.executeUpdate(query);

        stmt.close();
        con.close();
       }
     catch(Exception e)
       {
         System.out.println(e);
       }

      response.sendRedirect("List");

        out.println("</body>");
        out.println("</html>");
    }
}
