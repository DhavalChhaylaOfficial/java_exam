import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class Delete extends HttpServlet 
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor='cyan'>");

      String sno=request.getParameter("sno");

     Connection con=null;

     try
       {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "kk");

         String query="Delete from student where sno=" + sno;

         Statement stmt=con.createStatement();
         stmt.executeUpdate(query);

        stmt.close();
        con.close();
       }
     catch(Exception e)
       {
         System.out.println(e);
       }

      response.sendRedirect("List");

        out.println("</body>");
        out.println("</html>");
    }
}
