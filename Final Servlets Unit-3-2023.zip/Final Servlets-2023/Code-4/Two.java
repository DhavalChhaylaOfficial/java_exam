/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import jakarta.servlet.http.HttpServlet;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import jakarta.servlet.http.HttpServlet;

/**
 *
 * @author CHARUSAT
 */
public class Two extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            response.setContentType("text/html");
            PrintWriter out= response.getWriter();
     
            out.println("<html>");
            out.println("<body>");

            out.println("<body bgcolor='cyan'>"); out.println("<Font color='blue'>");
	
            int num1=Integer.parseInt(request.getParameter("fno"));
            int num2=Integer.parseInt(request.getParameter("sno"));
            int res=num1+num2;
            out.println(" Summation = "+res);     

            out.println("</body>");
            out.println("</html>");    
            out.close();
    }

    

}
