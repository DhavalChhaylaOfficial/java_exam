/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
/**
 *
 * @author CHARUSAT
 */
public class KKServletLifeCycle implements Servlet {
    
    
  ServletConfig config;
    // init() method
    @Override
    public void init(ServletConfig config) throws ServletException {
	System.out.println("init() Method Execution");        
	this.config=config;
        
    }

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        
         System.out.println("service() method execution...");
         response.setContentType("text/html");
         PrintWriter out=response.getWriter();
         out.println("<h1>Welcome Innocent & Beloved Students of MCA-I</h1>");
         out.println("<h1>The Server Time is:"+new Date()+"</h1>");
    }
    @Override
    public void destroy() {
        System.out.println("Destroy Method Execution...");
    }
    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }
    @Override
    public String getServletInfo() {
        return "Servlet Developed by KK ";
    }

    
}
