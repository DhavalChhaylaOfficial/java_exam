/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;



/**
 *
 * @author CHARUSAT
 */
public class RegistrationPage extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out= response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor='yellow'>"); 
        out.println("<Font color='blue'>");
        out.println("<center>");
        out.println("<head>");
        out.println("<title> Registration Form </title>");
        out.println("</head>");
        out.println("Registration Form <br><br>");
        out.println("<form action = 'WelcomePage' method = 'Post'>");
        out.println("Name: <Input Type = 'Text' Name = 'name'><br>");
        out.println("Email: <Input Type = 'Text' Name = 'email'><br>");
        out.println("Password: <Input Type = 'Password' Name = 'pwd'><br>");
        out.println("<Input Type = 'Submit' Value = 'submit'><br>");
        out.println("</Form>");
        out.println("</center>");
        out.println("</body>");
        out.println("</html>");
        out.close();  
       
    }

   

}
