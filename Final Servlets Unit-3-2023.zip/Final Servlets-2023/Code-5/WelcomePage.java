/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author CHARUSAT
 */
public class WelcomePage extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
        String email= request.getParameter("email");
        String pwd = request.getParameter("pwd");
        
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor='cyan'>"); 
        out.println("<Font color='blue'>");
        out.println("<center>");
        out.println("Welcome Page <br><br>");
        out.println("<table border= '1'>");
        out.println("<tr><td>");
        out.println("Your Name is : "+name);
        out.println("</td></tr>");
        
        out.println("<tr><td>");
        out.println("Your Email is :"+email);
        out.println("</td></tr>");
       
        out.println("<tr><td>");
        out.println("Your Password is :"+ pwd);
        out.println("</td></tr>");
        out.println("</center>");
        out.println("</body>");
        out.println("</html>");
    } 
    
}
