/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class Cookies1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor ='cyan'>");

        out.println("<form action='Cookies2'>");
        out.println("Name: <input type='text' name='uname'><br>");
        out.println("Password: <input type='password' name='pass'><br>");
        out.println("<input type='submit' value='Submit'><br>");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }
    

}
