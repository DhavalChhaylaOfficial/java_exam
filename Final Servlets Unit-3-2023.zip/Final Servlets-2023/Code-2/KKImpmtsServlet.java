/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class KKImpmtsServlet implements Servlet  {
    ServletConfig config;
    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config=config;
        System.out.println("Servlet Initilazation");
    }
    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }
    @Override
    public void service(ServletRequest request, ServletResponse response) 
            throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<h1> Welcome Innocent & Beloved Students of MCA-I Div-II   </h1>");
        out.println("</body>");
        out.println("</html>");
        
    }
    @Override
    public String getServletInfo() {
        return " This Servlet is Developed by KK";
    }

    @Override
    public void destroy() {
        System.out.println("Servlet Destroyed");
    }

   
}
