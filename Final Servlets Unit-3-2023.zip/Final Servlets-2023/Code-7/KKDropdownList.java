/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class KKDropdownList extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("Text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        
        out.println("<Form action='KKRadio'>"); 
        out.println("<body bgcolor= 'cyan'>");
        out.println("First No:<input type= 'text' name = 'fno'><br><br>");
        out.println("Second No:<input type= 'text' name = 'sno'><br><br>");
        
        out.println("Choose Mathematical Operation:");
        out.println("<select name = 'oper'>");
        out.println("<option value='sum'>Summation</option>");
        out.println("<option value='sub'>Subtraction</option>");
        out.println("<option value='mul'>Multiplication</option>");
        out.println("<option value='div'>Division</option>");
        out.println("</select>");
        out.println("<br><br><input type = 'submit' value = 'Result'>");
        
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");

        
    }

    
    
}
