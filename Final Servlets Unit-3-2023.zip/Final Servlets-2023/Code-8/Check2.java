/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Check2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor ='pink'>");
   
        String arr[] = request.getParameterValues("player");
        String str=" ";
        
        out.println("<b>Your Selected Favourite Players are : <br><br>");
        
        for(int i=0; i<arr.length;i++)
            str= str + arr[i]+ "   ";
        
        out.println(str );
        
        out.println("</body>");
        out.println("</html>");
        

    }

   
}
