/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Check1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor ='cyan'>");
        
        out.println("<Form action= 'Check2'>");
        out.println("<br><b>Choose Your Favourite Players:----- <br><br>");
        out.println("<input type = 'checkbox' name = 'player' value= 'Sachin Tendulkar'>Sachin Tendulkar<br><br>");
        out.println("<input type = 'checkbox' name = 'player' value= 'Virendra Sehwag'>Virendra Sehwag<br><br>");
        out.println("<input type = 'checkbox' name = 'player' value= 'Mahendra Singh Dhoni'>Mahendra Singh Dhoni<br><br>");
        out.println("<input type = 'checkbox' name = 'player' value= 'Rohit Sharma'>Rohit Sharma<br><br>");
        out.println("<input type = 'checkbox' name = 'player' value= 'Ravindra Jadeja'>Ravindra Jadeja<br><br>");
        out.println("<br><input type = 'submit' value= 'Result'>");
        
        out.println("</Form>");
        out.println("</body>");
        out.println("</html>");
    }

    
    
}
