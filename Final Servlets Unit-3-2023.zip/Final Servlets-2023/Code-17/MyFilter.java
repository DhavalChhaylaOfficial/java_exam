/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kk;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;

/**
 *
 * @author CHARUSAT
 */
public class MyFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) 
            throws ServletException {
        
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc) 
            throws IOException, ServletException {
        System.out.println("Filter Before Servlet");
        //......
        //......
        fc.doFilter(request, response);
        System.out.println("Filter After Servlet");
        //......
        //......
    }

    @Override
    public void destroy() {
        
    }
}
