/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author CHARUSAT
 */
public class KKGetAttributeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // get application-scoped attribute
        String applicationScope = (String)request.getServletContext().getAttribute("name");
        // get session scoped attribute
        HttpSession session = request.getSession();
        String sessionScope = (String)session.getAttribute("name");
       
        // get request scoped attribute
        String requestScope = (String)request.getAttribute("name");
        // print response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<body bgcolor = 'cyan'>");
        out.println("<h2>Servlet Attributes Example: Application Scope, Session Scope and Request Scope</h2>");
        out.println("<p><b>ApplicationScope : " + applicationScope + "</p>");
        out.println("<p>SessionScope: " + sessionScope + "</p>");
        out.println("<p>RequestScope: " + requestScope + "</p>");
        if(session != null) {
        session.removeAttribute("name");}
    }
}
