<?xml version="1.0" encoding="UTF-8"?>
<web-app version="6.0" xmlns="https://jakarta.ee/xml/ns/jakartaee" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd">
    <servlet>
        <servlet-name>KKFirst</servlet-name>
        <servlet-class>kk.KKGetAttributeServlet</servlet-class>
    </servlet>
    <servlet>
        <servlet-name>KKSecond</servlet-name>
        <servlet-class>kk.KKSetAttributeServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>KKFirst</servlet-name>
        <url-pattern>/KKGetAttributeServlet</url-pattern>
    </servlet-mapping>
    <servlet-mapping>
        <servlet-name>KKSecond</servlet-name>
        <url-pattern>/KKSetAttributeServlet</url-pattern>
    </servlet-mapping>
</web-app>


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package kk;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author CHARUSAT
 */
public class KKSetAttributeServlet extends HttpServlet {

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // set application scoped attribute
        request.getServletContext().setAttribute("name", "Application Scoped Attribute");
        // set session scoped attribute
        HttpSession session = request.getSession();
        session.setAttribute("name", "Session Scoped Attribute");
        // set request scoped attribute
        request.setAttribute("name", "Request Scoped Attribute");
        // send redirect to other servlet
        RequestDispatcher rd = request.getRequestDispatcher("KKGetAttributeServlet");
        rd.forward(request, response);
        
    }
}

       
    

