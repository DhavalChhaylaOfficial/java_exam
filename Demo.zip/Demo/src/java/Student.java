import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author megha
 */
public class Student {
    
      PreparedStatement addStud(HttpServletRequest request, HttpServletResponse response) {
        Connection con;
        try {
            String name = request.getParameter("trainee_name");
            String email = request.getParameter("email");
            String username = request.getParameter("user_name");
            String password = request.getParameter("pass_word");

            Class.forName("oracle.jdbc.OracleDriver"); 

            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin"); 

            String sql = "INSERT INTO Reg VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, username);
            pstmt.setString(4, password);

            pstmt.executeUpdate();  
            return pstmt;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
