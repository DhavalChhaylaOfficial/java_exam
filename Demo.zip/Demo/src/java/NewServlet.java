/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

/**
 *
 * @author megha
 */
public class NewServlet extends HttpServlet {

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        out.println("<body bgcolor ='pink'>");
   
        String arr[] = request.getParameterValues("player");
        String str=" ";
        
        out.println("<b>Your Selected Favourite Players are : <br><br>");
        
        for(int i=0; i<arr.length;i++)
            str= str + arr[i]+ "    <br> ";
        
        out.println(str );
        
        out.println("</body>");
        out.println("</html>");
    }
   

}
