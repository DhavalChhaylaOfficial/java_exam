/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


/**
 *
 * @author megha
 */
public class Controller extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       response.setContentType("text/html");
       PrintWriter out = response.getWriter();
       
       out.println("<html>"); 
       out.println("<body>"); 
       
        String oper=request.getParameter("oper");
        if(oper.equals("Add"))
         {
           Student s = new Student();
           PreparedStatement rs = s.addStud(request, response);
           request.setAttribute("Add", rs); 
           RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
           rd.forward(request, response);
         }

        out.println("</body>"); 
        out.println("</html>"); 
    }
}
