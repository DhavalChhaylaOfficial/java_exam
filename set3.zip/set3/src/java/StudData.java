/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
/**
 *
 * @author megha
 */
public class StudData extends HttpServlet {
@Override
 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException {
 resp.setContentType("text/html");
 PrintWriter out = resp.getWriter();
 HttpSession session = req.getSession();
 String id =(String)session.getAttribute("Id");

 String name = req.getParameter("studname");
 String email = req.getParameter("studmail");
 String Dob = req.getParameter("studDob");
 String gen = req.getParameter("studgen");

 Connection con= null;
 try{

 Class.forName("oracle.jdbc.OracleDriver");
 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
 String query = "insert into StudDetails3 values('"+ name +"','" +
 email +"','" +Dob +"','" + gen + "','" + id +"')";
 Statement stmt = con.createStatement();
 stmt.executeUpdate(query);
 stmt.close();
 con.close();

 if(gen.equals("Male"))
 {
 resp.sendRedirect("Male.jsp?user=" + name+ "&id="+id +"&DOB=" + Dob );

 }
 else
 {
 resp.sendRedirect("Female.jsp?user=" + name+ "&id="+id +"&DOB=" + Dob );
 }
 }
 catch(Exception e)
 {
 System.out.println(e);
 }   
 }

    
}
