/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


/**
 *
 * @author megha
 */
public class LoginValidation extends HttpServlet {

   @Override
 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException {
 resp.setContentType("text/html");
 String id = req.getParameter("studid");
 String pass = req.getParameter("pass");
 PrintWriter out = resp.getWriter();
 Connection con = null;
 int result =0;
 try{
 Class.forName("oracle.jdbc.OracleDriver");

 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
 String query= "select * from StudLogin3";
 Statement stmt = con.createStatement();
 ResultSet rs = stmt.executeQuery(query);
 while(rs.next())
 {
 if(rs.getString("id").equals(id) && rs.getString("Passsward").equals(pass))
 {
 result =1;
 HttpSession session = req.getSession();
 session.setAttribute("Id", id);
 break;
 }
 }
 if(result ==1)
 {
 RequestDispatcher rd = req.getRequestDispatcher("Dashboard.jsp");
 rd.forward(req, resp);
 }
 else
 {
 out.println("Invliad id password try agian!!");
 RequestDispatcher rd = req.getRequestDispatcher("Login.jsp");
 rd.include(req, resp);
 }

 }
 catch(Exception e)
 {
 System.out.println(e);
 }

 }

}
