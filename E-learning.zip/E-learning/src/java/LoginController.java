/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author megha
 */
public class LoginController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String userPassword = request.getParameter("password");

        LoginModel login = new LoginModel(username, userPassword);
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            PreparedStatement ps1 = con.prepareStatement("SELECT * FROM Reg WHERE username=? AND password=?");
            ps1.setString(1, login.getUsername());
            ps1.setString(2, login.getPassword());

            ResultSet rs = ps1.executeQuery();
            if (rs.next()) {
                // Successful login
                HttpSession session = request.getSession(); // Create a session if it doesn't exist
                session.setAttribute("username", login.getUsername());
                response.sendRedirect("Home.jsp"); // Redirect to the home page
            } else {
                // Invalid credentials
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Invalid username or password. Please try again.');");
                out.println("window.location.href='Login.jsp';");
                out.println("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
