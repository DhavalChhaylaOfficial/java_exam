/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

public class Controller extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String userPassword = request.getParameter("password");

        Model registration = new Model(name, email, username, userPassword);

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");

            PreparedStatement ps = con.prepareStatement("INSERT INTO Reg (name, email, username, password) VALUES (?, ?, ?, ?)");
            ps.setString(1, registration.getName());
            ps.setString(2, registration.getEmail());
            ps.setString(3, registration.getUsername());
            ps.setString(4, registration.getPassword());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("Login.jsp"); // Redirect to a success page
            } else {
                response.sendRedirect("Error.jsp"); // Redirect to an error page
            }
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
       
    }
}
