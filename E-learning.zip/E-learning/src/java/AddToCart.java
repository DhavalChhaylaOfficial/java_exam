/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author megha
 */
public class AddToCart extends HttpServlet {
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
        double price = Double.parseDouble(request.getParameter("price"));

        HttpSession session = request.getSession();
        double cartTotal = 0;

        if (session.getAttribute("cartTotal") != null) {
            cartTotal = (Double) session.getAttribute("cartTotal");
        }

        cartTotal += price;
        session.setAttribute("cartTotal", cartTotal);

        response.sendRedirect("Home.jsp"); 
    }
  
}
