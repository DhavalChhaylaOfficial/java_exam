/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class Purchase extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor = 'LightSkyBlue'>");
        out.println("<center><h1>Purchase Book <h1> <Center>");
        Connection con = null;
        String book_name = "";
        String book_price = "";
        String book_id = "";
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con
                    = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","admin");
            String id = request.getParameter("id");
            String query = "Select * from Book where id=" + id;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            out.println("<table>");
            while (rs.next()) {
                book_id = rs.getString("id");
                book_name = rs.getString("name");
                book_price = rs.getString("price");
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        out.println("<form action = 'Order'>");
        out.println("<table border = '1' align='center' bgcolor='yellow' >");
        out.println("<tr><td>Book Name</td> <td>" + book_name + "<input type='hidden'name = 'book_name'value ='" + book_name + "'> </td></tr>");

        out.println("<tr><td>Book Price</td> <td>" + book_price + "<input type='hidden'name = 'book_price'value ='" + book_price + "'> </td></tr>");

        out.println("<tr><td>Quantity</td> <td><input type='text'name ='quantity'></td> </tr>");
        out.println("<tr><th colspan='2'><input type='submit'value ='Submit'></th> </ tr>");
        out.println("</table>");
        out.println("</form>");
    }

}
