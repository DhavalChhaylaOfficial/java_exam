/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
/**
 *
 * @author megha
 */
public class List_Books extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest requst, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor= 'cyan'>");
        out.println("<center><h1> CRUD Operation On Student Table<h1><Center>");

        Connection con = null;
        try {
            //Loading driver
            Class.forName("oracle.jdbc.OracleDriver");
            //Building bridge between java & database
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","admin");
            //Building query
            String query = "Select * from Book";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            out.println("<table border = '1' align='center'>");
            out.println("<tr>");
            out.println("<th> Book Name </th>");
            out.println("<th> Book Price </th>");
            out.println("<th>Purchase </th>");
            out.println("</tr>");
            while (rs.next()) {
                String id = rs.getString("id");
                String book_name = rs.getString("name");
                String book_price = rs.getString("price");
                out.println("<tr>");
                out.println("<td>" + book_name +"</td>");
                out.println("<td>" + book_price + "</td>");
                out.println("<td> <a href = 'Purchase?id=" + id + "'>Buy</a> </td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<br><Center><a href = 'Add_Books'>Add NewBook</a> </Center> <br>");
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            out.println(e);
        }
        out.println("</body>");
        out.println("</html>");
    }
}
