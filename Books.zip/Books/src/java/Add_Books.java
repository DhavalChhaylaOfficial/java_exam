/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class Add_Books extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor = 'pink'>");
        out.println("<center><h1>Insert Book <h1> <Center>");
        Connection con = null;
        int id = 0;

        try {

            Class.forName("oracle.jdbc.OracleDriver");

            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");

            String query = "Select max(id) maxnum from Book";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                id = rs.getInt("maxnum");
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        id++;
        out.println("<form action = 'Insert_book'>");
        out.println("<table border = '1' align='center' bgcolor='yellow' >");
        out.println("<tr><td>Student No:</td> <td>" + id + "<input type ='hidden' name = 'id' value ='" + id + "' > </td> </tr>");

        out.println("<tr><td>Book Name:</td><td> <input type='text' name ='book_name'> </td > <tr>");
        out.println("<tr><td>Book Price:</td><td> <input type='text'name ='book_price'> </ td> </tr>");
        out.println("<tr><th colspan='2'><input type='submit' value ='Submit'> </th> </tr>");
        out.println("</table>");
        out.println("</form>");
    }

}
