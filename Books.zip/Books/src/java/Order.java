/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author megha
 */
public class Order extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body bgcolor = 'LightSkyBlue'>");
        out.println("<center><h1>Your Bill<h1> ");
        String book_nm = request.getParameter("book_name");
        int book_pr = Integer.parseInt(request.getParameter("book_price"));
        int qty = Integer.parseInt(request.getParameter("quantity"));

        int total = book_pr * qty;

        out.println("<table border = '1' align='center' bgcolor='yellow' >");
        out.println("<tr><th colspan='2'>Bill</th></tr>");
        out.println("<tr><td>Book Name</td> <td>" + book_nm + "</td></tr>");
        out.println("<tr><td>Book Price</td> <td>" + book_pr + "</td></tr>");
        out.println("<tr><td>Quantity</td> <td>" + qty + "</td></tr>");
        out.println("<tr><td>Total Amount</td> <td>" + total + "</td></tr>");
        out.println("</table>");
        out.println("<h2>Thanks for Placing the Order <ahref ='List_Books'>List</a> </h2>");
        out.println("</center></body></html>");
    }
}
