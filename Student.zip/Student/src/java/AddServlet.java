/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.sql.*;


/**
 *
 * @author megha
 */
public class AddServlet extends HttpServlet {
  @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");

        Connection con = null;
        int id = 0;

        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            String query = "Select max(id) maxnum from Student2";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                id = rs.getInt("maxnum");
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        id++;
        out.println("<form action='InsertServlet'>");
        out.println("<table align='center'>");
        out.println("<tr><td>Student ID</td><td><input type='text' readonly name='id' value='" + id + "'></td></tr>");
        out.println("<tr><td>Student Name</td><td><input type='text' name='stdName' required placeholder='Name'></td></tr>");
        out.println("<tr><td>Marks1</td><td><input type='number' required name='marks1' placeholder='Marks1'></td></tr>");
        out.println("<tr><td>Marks2</td><td><input type='number' required name='marks2' placeholder='Marks2'></td></tr>");
        out.println("<tr><td>Marks1</td><td><input type='number' required name='marks3' placeholder='Marks3'></td></tr>");
        out.println("<tr colspan='2'><td><input type='submit' value='submit'></td></tr>");
        out.println("</table>");
        out.println("</form>");
        out.println("</body></html>");
    }
}
