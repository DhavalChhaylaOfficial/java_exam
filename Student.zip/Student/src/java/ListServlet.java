/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;


/**
 *
 * @author megha
 */
public class ListServlet extends HttpServlet {

   
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");

        try {
            Connection con = null;
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            String query = "Select * from Student2";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            out.println("<table border = '1' align='center'>");
            out.println("<tr><th>Student ID</th><th>Student Name</th><th>Marks1</th><th>Marks2</th><th>Marks3</th><th colspan='2'>Actions</th></tr>");

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String m1 = rs.getString("marks1");
                String m2 = rs.getString("marks2");
                String m3 = rs.getString("marks3");
                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + m1 + "</td><td>" + m2 + "</td><td>" + m3 + "</td><td><a href='CalculateServlet1?id=" + id + "'>Calculate</a></td></tr>");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            out.println("<h1>" + e + "</h1>");
        }

        out.println("</table>");
        out.println("</body></html>");
    }
}
