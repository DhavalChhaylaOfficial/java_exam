/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.DecimalFormat;

/**
 *
 * @author megha
 */
public class CalculateServlet1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");

        if (request.getParameter("id") == null) {
            response.sendRedirect("ListServlet");
        } else {
            int id = Integer.parseInt(request.getParameter("id"));
            Connection con = null;
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
                String query = "Select * from Student2 where id='" + id + "'";
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                out.println("<table border = '1' align='center'>");
                out.println("<tr><th>Student ID</th><th>Student Name</th><th>Marks1</th><th>Marks2</th><th>Marks3</th><th colspan='2'>Percentage</th></tr>");

                while (rs.next()) {
                    String name = rs.getString("name");
                    int m1 = Integer.parseInt(rs.getString("marks1"));
                    int m2 = Integer.parseInt(rs.getString("marks2"));
                    int m3 = Integer.parseInt(rs.getString("marks3"));
                    float total = m1 + m2 + m3;
                    float per = (total / 300) * 100;
                    DecimalFormat df = new DecimalFormat();
                    df.setMaximumFractionDigits(2);
                    out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + m1 + "</td><td>" + m2 + "</td><td>" + m3 + "</td><td>" + df.format(per) + "</td></tr>");
                }

                rs.close();
                stmt.close();
                con.close();
            } catch (Exception e) {
                out.println("<h1>" + e + "</h1>");
            }
        }
        out.println("</table>");
        out.println("</body></html>");
    }

}
