/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author megha
 */
public class InsertServlet extends HttpServlet {

  
   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection con = null;
        String id = request.getParameter("id");
        String name = request.getParameter("stdName");
        String marks1 = request.getParameter("marks1");
        String marks2 = request.getParameter("marks2");
        String marks3 = request.getParameter("marks3");

        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "admin");
            String query = "Insert into Student2 values(" + id + ",'" + name + "'," + marks1 + "," + marks2 + "," + marks3 + ")";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            stmt.close();
            con.close();
        } catch (Exception e) {
            out.println(e);
        }
        response.sendRedirect("ListServlet");
    }

}
