/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kkmvc;

/**
 *
 * @author CHARUSAT
 */
public class MVCmain {
    public static void main(String[] args) {
         // fetching the employee record based on the employee_id from the database  
         
         EmpModel em= new  EmpModel();
         EmpView ev= new EmpView();
         EmpController ec= new EmpController(em,ev);
         em.setEmpId("101");
         em.setEmpName("KK");
         ec.updateView();
         em.setEmpId("102");
         em.setEmpName("PK");
         ec.updateView();
        
    }
    
}
