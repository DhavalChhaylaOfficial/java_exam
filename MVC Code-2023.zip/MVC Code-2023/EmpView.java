/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kkmvc;

/**
 *
 * @author CHARUSAT
 */
public class EmpView {
    public  void EmpDispInfo(String empid, String empname)
    {
         System.out.println("Employee Details: "); 
         System.out.println("Employee ID: " + empid); 
         System.out.println("Name: " + empname);
          
    }
}
