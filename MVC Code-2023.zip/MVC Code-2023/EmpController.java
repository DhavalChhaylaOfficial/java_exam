/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kkmvc;

/**
 *
 * @author CHARUSAT
 */
public class EmpController {
    // declaring the variables model and view  
       private EmpModel model;  
       private EmpView view; 
       
   // constructor to initialize  
    public EmpController(EmpModel model, EmpView view) {
        this.model = model;
        this.view = view;
    }
     // getter and setter methods  
    public EmpModel getModel() {
        return model;
    }

    public void setModel(EmpModel model) {
        this.model = model;
    }

    public EmpView getView() {
        return view;
    }

    public void setView(EmpView view) {
        this.view = view;
    }
       
    // method to update view   
   
    public void updateView(){
        view.EmpDispInfo(model.getEmpId(),model.getEmpName());
    }
}
