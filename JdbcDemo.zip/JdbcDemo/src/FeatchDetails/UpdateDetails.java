/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FeatchDetails;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
/**
 *
 * @author megha
 */
public class UpdateDetails {
    public static void main(String[] args) {
        
        String value;
        int eid;
        double esal;
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
            
            Statement stmt = con.createStatement();
            
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Enter Employee ID: ");
            value = br.readLine();
            eid = Integer.parseInt(value);
            
            System.out.print("Enter new Salary: ");
            value = br.readLine();
            esal = Double.parseDouble(value);
            
            String q = "Update employee set Esalary ="+esal+"where eno ="+eid;
            int count = stmt.executeUpdate(q);
            
            if(count>0){
                System.out.println(count+"Rows Updated");
            }
            else {
                System.out.println("No Record Found");
            }
        }
        catch(Exception e) {
            System.err.println(e);
        }
    }
}
