/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FeatchDetails;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
/**
 *
 * @author megha
 */
public class DeleteDetails {
    public static void main(String[] args) {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
            
            Statement stmt = con.createStatement();
            
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            
            while(true) {
                System.out.print("Enter Deletion Employee Id: ");
                int Eno = Integer.parseInt(br.readLine());
                
                String q = "delete from employee where Eno="+Eno;
                int count = stmt.executeUpdate(q);
                if(count==1){
                    System.out.println(count+" Record Deleted");
                }
                else {
                    System.out.println("Record not Found");
                }
                
                System.out.print("Do you want to add more records [Yes/No]");
                
                String ch = br.readLine();
                if(ch.equalsIgnoreCase("no"))
                    break;
            }
        }
        catch (Exception e){
            System.err.println(e);
        }
    }
}
