/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FeatchDetails;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author megha
 */
public class InsertDetails {
    public static void main (String[] args) {
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
            
            String q = "insert into employee values (?,?,?)";
            
            PreparedStatement psmt = con.prepareStatement(q);
            
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            //Scanner sc = new Scanner(System.in);

            while(true) {
                System.out.print("Enter Employee ID: ");
                int Eno = Integer.parseInt(br.readLine());
                //int Eno = sc.nextInt();
                
                System.out.print("Enter Employee Name: ");
                String Ename = br.readLine();
                
                System.out.print("Enter Employee Salary: ");
                double Esalary = Double.parseDouble(br.readLine());
                
                psmt.setInt(1,Eno);
                psmt.setString(2,Ename);
                psmt.setDouble(3,Esalary);
                
                int count = psmt.executeUpdate();
                if(count>0){
                    System.out.println(count+" record inserted");
                }
                else {
                    System.out.println("No record inserted");
                }
                System.out.print("Do you want to add more records [Yes/No]");
                
                String ch = br.readLine();
                if(ch.equalsIgnoreCase("no"))
                    break;
            }
        }
        catch (Exception e) {
            System.err.println("e");
        }
    }
}
